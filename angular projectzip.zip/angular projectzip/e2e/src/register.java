import java.sql.Connection;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;  
import java.io.*;

public class register extends HttpServlet {
	
	private static final long serialVersionUID = 1L;

   
public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
{
   
	response.setContentType("text/html");
	PrintWriter out = response.getWriter();
	
	
	//String f=request.getParameter("registerReqestData.firstname");
	//String l=request.getParameter("registerReqestData.lastname");
    //String e=request.getParameter("registerReqestData.email");
    //String p=request.getParameter("registerReqestData.password");
    //String ph=request.getParameter("registerReqestData.phone");
	
 

	  try
	   {
      	  Class.forName("org.sqlite.JDBC");
          Connection conn = DriverManager.getConnection("jdbc:sqlite:C:\\sqlite3\\Emp.db");  
          Statement stmt  = conn.createStatement();  
          ResultSet rs    = stmt.executeQuery("select * from EmpInfo");
          while(rs.next())
          {
        	  
        	  out.println(rs.getString("firstname")+"\t"+rs.getString("lastname")+"\t"+rs.getString("email")+"\t"+rs.getString("password")+"\t"+rs.getString("phone")+".............");
        	  
          }
	  }
	  catch (SQLException e) 
	   {  
          System.out.println(e.getMessage());  
      	   } 
         catch (ClassNotFoundException e) 
            {		
		e.printStackTrace();
	    } 
	 out.close(); 
  
  
}  
    
   
} 