import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'pipeDemo'
})
export class PipeDemoPipe implements PipeTransform {

  transform(value: any,input:string) {
    if(input){
      input=input.toLocaleLowerCase();
      return value.filter(function(name:any){
        return name.name.toLocaleLowerCase().indexOf(input) > -1;
        })
    }
    return value;
  }

}
