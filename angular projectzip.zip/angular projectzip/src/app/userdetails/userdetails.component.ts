import { Component, OnInit } from '@angular/core';
import { RouterModule,Routes,Router,ActivatedRoute } from '@angular/router';
import { ServiceService} from '../service.service';


@Component({
  selector: 'app-userdetails',
  templateUrl: './userdetails.component.html',
  styleUrls: ['./userdetails.component.css']
})
export class UserdetailsComponent implements OnInit {
  private details  : any; 
  sub:any;
  id:any;
 
  constructor(private route: ActivatedRoute,private UsersService:ServiceService) { }

  ngOnInit() {
    
  this.sub = this.route.params.subscribe(params => {
    this.id = params['id'];
    });
    this.userdetails();
  
    }
    
    userdetails(){
    
      this.UsersService.get_productbyId(this.id).subscribe((res : any[])=>{
      this.details= res;  
      });
  }
  }


