import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EditjsonComponent } from './editjson.component';

describe('EditjsonComponent', () => {
  let component: EditjsonComponent;
  let fixture: ComponentFixture<EditjsonComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditjsonComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditjsonComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
