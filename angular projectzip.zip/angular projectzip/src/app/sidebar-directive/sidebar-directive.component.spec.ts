import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SidebarDirectiveComponent } from './sidebar-directive.component';

describe('SidebarDirectiveComponent', () => {
  let component: SidebarDirectiveComponent;
  let fixture: ComponentFixture<SidebarDirectiveComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SidebarDirectiveComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SidebarDirectiveComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
