import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sidebar-directive',
  templateUrl: './sidebar-directive.component.html',
  styleUrls: ['./sidebar-directive.component.css']
})
export class SidebarDirectiveComponent implements OnInit {
  name = 'Angular 6';
  constructor() { }

  ngOnInit() {
  }
  openNav() {
    document.getElementById("mySidenav").style.width = "250px";
  }
  closeNav() {
    document.getElementById('mySidenav').style.width = '0';
  }  
}
