import { Component, OnInit } from '@angular/core';
import { ServiceService} from '../service.service';
import { RouterModule,Routes,Router } from '@angular/router';
@Component({
  selector: 'app-getdata',
  templateUrl: './getdata.component.html',
  styleUrls: ['./getdata.component.css']
})
export class GetdataComponent implements OnInit {
  firstname:any;
  email:any;
  islogged:boolean=false;
  groups:any;
  data:boolean=false;
  name:any[];
  private  products  = []; 
  showtable:boolean =false;
  constructor(private  serviceuser:ServiceService,private router: Router) { }

  ngOnInit() {
     if(localStorage.getItem('val')){
      this.firstname=localStorage.getItem('fname');
      this.email=localStorage.getItem('emaill');
     }
  }
  // getdata()
  // {
  //   this.data=true;
  // }
  get_product(){
    
    this.showtable=true;
      this.serviceuser.get_product().subscribe((res : any[])=>{
      this.products = res;
      });
    
  }
  
  
}
