import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl} from '@angular/forms';
import {RouterModule,Routes,Router} from '@angular/router';
import {registerRequest} from '../model/employee';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import {GoTopButtonModule} from 'ng2-go-top-button';
@Component({
  selector: 'app-sample',
  templateUrl: './sample.component.html',
  styleUrls: ['./sample.component.css']
})
export class SampleComponent implements OnInit {
  onFileSelected(event){
    console.log(event);
  }
registerform:FormGroup;
registerReqestData:registerRequest;
submitted=false;

  constructor(private formBuilder: FormBuilder, public router:Router,private spinner: NgxSpinnerService,private toastr: ToastrService) { }

  ngOnInit() {
    this.registerReqestData = new registerRequest();
    this.registerform = this.formBuilder.group({
     firstname: ['', Validators.required],
     lastname: ['', Validators.required],
     email: ['', [Validators.required, Validators.email]],
     password: ['', [Validators.required, Validators.minLength(6)]],
     phone: ['', Validators.required]
     });
     this.spinner.show();
    
     setTimeout(() => {
         /** spinner ends after 5 seconds */
         this.spinner.hide();
     }, 2000);
     

  }
  submit(){ 
    this.submitted=true;
    
      
    
    if(this.registerform.invalid)
    {
  //alert("enter all the values");
  this.toastr.error('Fill the details');
  return false;
    }
    else{
    localStorage.setItem('fname',this.registerReqestData.firstname);
    localStorage.setItem('lname',this.registerReqestData.lastname);
    localStorage.setItem('emaill',this.registerReqestData.email);
    localStorage.setItem('password',this.registerReqestData.password);
    localStorage.setItem('phone',this.registerReqestData.phone);
    this.toastr.success('employee details upploaded');
  this.router.navigate(['/home']);
    }
  }  

}
