import { Injectable } from '@angular/core';
import {HttpClient, HttpHeaders,HttpClientModule} from '@angular/common/http';
import { Observable } from 'rxjs';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';

@Injectable({
  providedIn: 'root'
})
export class ServiceService {

  constructor(private httpClient: HttpClient) { }
  get_product(){
    return this.httpClient.get('/assets/mock/test/test.json');
  
 }
//  get_product(){
//   return this.httpClient.get('https://jsonplaceholder.typicode.com/users');
// }
 get_productbyId(id:any){   
  return this.httpClient.get('/assets/mock/test/test.json'+id);
}
get_addr(name:any){
  return this.httpClient.get('/assets/mock/test/test.json'+name);
}
}
