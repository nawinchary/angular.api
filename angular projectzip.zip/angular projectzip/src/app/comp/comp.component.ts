import { Component, OnInit } from '@angular/core';
import { Http } from '@angular/http';
import {HttpClient, HttpHeaders,HttpClientModule} from '@angular/common/http';
import 'rxjs/add/operator/toPromise';
@Component({
  selector: 'app-comp',
  templateUrl: './comp.component.html',
  styleUrls: ['./comp.component.css']
})
export class CompComponent implements OnInit {
 dukes=[{name:"naveen", age:20},{name:"vamsi", age:22 }]; 
  constructor(private httpClient: HttpClient) { }

  ngOnInit() {
    this.httpClient.get('http://localhost:8082/UserInfo/register');
    
  }

}
