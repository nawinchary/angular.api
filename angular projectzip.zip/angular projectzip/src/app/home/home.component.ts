import { Component, OnInit } from '@angular/core';
import { RouterModule,Routes,Router } from '@angular/router';
import {registerRequest} from '../model/employee';
import { NgxSpinnerService } from 'ngx-spinner';
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
firstname:any;
lastname:any;
email:any;
phone:any;
public imagesUrl;

  constructor(private router: Router,private spinner: NgxSpinnerService) { }

  ngOnInit() {
    
    this.firstname=localStorage.getItem('fname');
    this.lastname=localStorage.getItem('lname');
    this.email=localStorage.getItem('emaill');
    this.phone=localStorage.getItem('phone');
    
    this.spinner.show();
 
    setTimeout(() => {
        /** spinner ends after 5 seconds */
        this.spinner.hide();
    }, 2000);
    this.imagesUrl = [
      './assets/images/download.png',
      './assets/images/unsplash.jpg',
      './assets/images/edit.png',
      './assets/images/unsplash1.jpg',
      './assets/images/EMPLOYEE.jpg',
      './assets/images/unsplash.jpg',
      './assets/images/images3.jpg',
      './assets/images/unsplash.jpg',

      ];
  }
  
  addemployee(){
  
  this.router.navigate(['/sample']);
  
 
}
editdata(){
this.router.navigate(['/edit']);

}
deletedata(){
  localStorage.clear();
}

viewdata(){
  this.router.navigate(['/view']);
}
test(){
  this.router.navigate(['/test']);
}
get_product(){

this.router.navigate(['/getdata']);

}
navdata(){
  this.router.navigate(['/nav']);
}
}
