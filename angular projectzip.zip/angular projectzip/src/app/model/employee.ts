export class registerRequest{

firstname:any;
lastname:any;
email:any;
password:any;
phone:any;

}