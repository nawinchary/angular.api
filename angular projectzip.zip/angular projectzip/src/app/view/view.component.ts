import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view',
  templateUrl: './view.component.html',
  styleUrls: ['./view.component.css']
})
export class ViewComponent implements OnInit {
  firstname:any;
  lastname:any;
  email:any;
  phone:any;
  
  constructor() { }

  ngOnInit() {
    this.firstname=localStorage.getItem('fname');
    this.lastname=localStorage.getItem('lname');
    this.email=localStorage.getItem('emaill');
    this.phone=localStorage.getItem('phone');
    

  }

}
