import { Component, OnInit } from '@angular/core';
import { Http, Response } from "@angular/http";
import {HttpClient, HttpHeaders,HttpClientModule} from '@angular/common/http';
import { HttpModule, JsonpModule } from '@angular/http';
import {Observable}     from 'rxjs/Observable';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';
export type Item = { id: number, name: string };
@Component({
  selector: 'app-test',
  templateUrl: './test.component.html',
  styleUrls: ['./test.component.css']
})
export class TestComponent implements OnInit {
  items: Array<Item>;
  
  constructor(private httpClient: HttpClient) { }

  ngOnInit() {
    this.httpClient
    .get("/assets/mock/test/test.json")
  
    .subscribe(data => {
    
      console.log(data);
    });
  }

}
