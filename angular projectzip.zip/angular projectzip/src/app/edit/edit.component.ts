import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators,FormBuilder } from '@angular/forms';
import { RouterModule,Routes,Router } from '@angular/router';
import {registerRequest} from '../model/employee';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.css']
})
export class EditComponent implements OnInit {
	onFileSelected(event){
		console.log(event);
	  }
   //Component properties
   registerform:FormGroup;
   registerReqestData:registerRequest;
   submitted=false;
	 constructor(private router:Router,private formBuilder: FormBuilder,private toastr: ToastrService) { }
 
	 ngOnInit() {
		
		 this.registerReqestData = new registerRequest();
 this.registerform = this.formBuilder.group({
  firstname: ['', Validators.required],
  lastname: ['', Validators.required],
  email: ['', [Validators.required, Validators.email]],
  password: ['', [Validators.required, Validators.minLength(6)]],
  phone: ['', Validators.required]
  });
}
	 edit(){
     this.submitted=true;

    
     if(this.registerform.invalid)
     {
   //alert("enter all the values");
   return false;
     }
     else{
		localStorage.setItem('fname',this.registerReqestData.firstname);
  localStorage.setItem('lname',this.registerReqestData.lastname);
  localStorage.setItem('emaill',this.registerReqestData.email);
  localStorage.setItem('password',this.registerReqestData.password);
  localStorage.setItem('phone',this.registerReqestData.phone);
  
  this.toastr.success('employee details upploaded');
		 this.router.navigate(['/home']);
 }
}
 }