import { BrowserModule } from '@angular/platform-browser';
import { NgModule, Component } from '@angular/core';
import { FormsModule,ReactiveFormsModule} from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { EmployeeComponent } from './employee/employee.component';
import { RouterModule,Routes } from '@angular/router';
import { EditComponent } from './edit/edit.component';
import { NgxSpinnerModule } from 'ngx-spinner';
import { ViewComponent } from './view/view.component';
import { ToastrModule } from 'ngx-toastr';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { FooterComponent } from './footer/footer.component';
import {GoTopButtonModule} from 'ng2-go-top-button';
import {HttpClient, HttpHeaders,HttpClientModule} from '@angular/common/http';
import { HttpModule } from '@angular/http';
import { GetdataComponent } from './getdata/getdata.component';
import { ServiceService} from './service.service';
import { PipeDemoPipe } from './pipe-demo.pipe';
import { UserdetailsComponent } from './userdetails/userdetails.component';
import { SampleComponent } from './sample/sample.component';
import { SliderModule } from 'angular-image-slider';
import { StyleComponent } from './style/style.component';

import { CustomMaterialModule } from './material.module';


import {TestComponent} from './test/test.component';
import { DemoComponent } from './demo/demo.component';
import { EditjsonComponent } from './editjson/editjson.component';
import { ArticleComponent } from './article/article.component';
import { ArticleService } from './article.service';
import { Article1Component } from './article1/article1.component';
import { CompComponent } from './comp/comp.component';
import { LoginComponent } from './login/login.component';
import { UserComponent } from './user/user.component';
import { NewComponentComponent } from './new-component/new-component.component';
import { SidebarDirectiveComponent } from './sidebar-directive/sidebar-directive.component';
import { BootstrapComponent } from './bootstrap/bootstrap.component';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    EmployeeComponent,
    EditComponent,
    ViewComponent,
    FooterComponent,
    GetdataComponent,
    PipeDemoPipe,
    UserdetailsComponent,
    SampleComponent,
    StyleComponent,
    TestComponent,
    DemoComponent,
    EditjsonComponent,
    ArticleComponent,
    Article1Component,
    CompComponent,
    LoginComponent,
    UserComponent,
    NewComponentComponent,
    SidebarDirectiveComponent,
    BootstrapComponent
    
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    CustomMaterialModule,
    SliderModule,
    BrowserAnimationsModule,
    ToastrModule.forRoot(),
    FormsModule,
    GoTopButtonModule,
    ReactiveFormsModule,
    NgxSpinnerModule,
    AppRoutingModule,
    RouterModule.forRoot([
      {path:'home', component:HomeComponent},
      {path:'employee', component:EmployeeComponent},
      {path:'edit', component:EditComponent},
      {path:'view', component:ViewComponent},
      {path:'getdata', component:GetdataComponent},
      {path:'comp', component:CompComponent},
      {path:'sample', component:SampleComponent},
      {path:'bootstrap', component:BootstrapComponent},
      {path:'style', component:StyleComponent},
      {path:'demo', component:DemoComponent},
      {path:'userdetails', component:UserdetailsComponent},
      {path:'editjson', component:EditjsonComponent},
      {path:'article', component:ArticleComponent},
      {path:'article1', component:Article1Component},
      {path:'test', component:TestComponent},
      { path: 'user', component: UserComponent },
      {path:'sidebar', component:SidebarDirectiveComponent},
      { path: 'newcomponent', component: NewComponentComponent },
      { path: 'login', component: LoginComponent },
      {path:'**', redirectTo:'home'},
      
      
    ])
  ],
  providers: [HttpClient,ServiceService,ArticleService],
  bootstrap: [AppComponent]
})
export class AppModule { }
